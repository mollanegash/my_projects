package ProAssignment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Driver {

	public static void main(String[] args) throws IOException {

		Driver dr = new Driver();
		dr.doIt();

	}

	public void doIt() throws IOException {

		TextParseAndLinkedList mll = new TextParseAndLinkedList();
		String doc = mll.readingText();
		String[] st = doc.split(" ");

		//insert all elemnts to the linked list
		for (String each : st) {
			mll.addToLinkedList(each);
		}
		//print all elements of the linked list
		//mll.printWwithCount();
		
		//mll.printWordAndFrequency();
		//System.out.println("unique entries of " + mll.getHeadSize()); 
		
		//mll.printWordAndHighestFrequency().forEach(x -> System.out.println(x.getData() + "" + x.getCount()));
		List<Node> nodes = mll.printWordAndHighestFrequency();
		for(Node x : nodes) {
			System.out.println(x.getData() + "" + x.getCount());
		}
		//mll.searchIrritating();
		/*//System.out.println(mll.readingText());
		System.out.println("portrait:" + " " + mll.countWordOccurance("portrait"));
		System.out.println("persian:" + " " + mll.countWordOccurance("persian"));
		System.out.println("dorian:" + " " + mll.countWordOccurance("dorian"));
		System.out.println("experiment:" + " " + mll.countWordOccurance("experiment"));
		System.out.println("magnetic:" + " " + mll.countWordOccurance("magnetic"));
		System.out.println("number of entries:" + " " + mll.numberOfEntries());
		System.out.println(mll.wordsOccuredMoreThan20Times());
		System.out.println(mll.frequentWord());
		System.out.println(mll.longestWord());
		System.out.println(mll.wordBeforeIrritating());*/

	}

}
