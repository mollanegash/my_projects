package ProAssignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextParseAndLinkedList {
	private Node tempNode = null;
	private Node head = null;
	private int headSize = 0;

	public TextParseAndLinkedList() {
		super();
	}

	public int getHeadSize() {
		return headSize;
	}

	public void setHeadSize(int headSize) {
		this.headSize = headSize;
	}

	public String readingText() throws FileNotFoundException {
		File file = new File("D:\\Mola MUM\\readfile.txt");
		Scanner sc = new Scanner(file);
		sc.useDelimiter("\\Z");
		String str = sc.next().toLowerCase();
		Pattern p = Pattern.compile("\\p{Punct}");
		Matcher m = p.matcher(str);
		str = m.replaceAll("");
		return str;
	}

	public void addToLinkedList(String str) {
		if (head == null) {
			head = new Node(str);
			head.setPrevious(null);
			head.setNext(null);
			head.count = 1;
		} else if (search(str) == 0) {
			setHeadSize(getHeadSize() + 1); // unique entries
			tempNode = new Node(str);
			tempNode.setPrevious(head);
			tempNode.setNext(null);

			head.setNext(tempNode);
			head = tempNode;
			head.count = 1;
		}
	}

	public int search(String str) {
		int count = 0;
		while (head.previous != null) {
			if (head.getData().equalsIgnoreCase(str)) {
				count++;
				head.count++;
			}
			head = head.previous;
		}
		return count;
	}

	public void printWordAndFrequency() {
		while (head.next != null) {
			System.out.println(head.data + " " + head.count);
		}
	}

	public void printWordAndFrequencyMoreThan20() {
		while (head.next != null) {
			if (head.count > 20) {
				System.out.println(head.data + " " + head.count);
			}
		}
	}

	public void printWwithCount() {
		int c = 0;
		while (head.previous != null && c < 20) {
			System.out.println(head.data + " count = " + head.count);
			head = head.previous;
			c++;
		}
	}

	public List<Node> printWordAndHighestFrequency() {
		List<Node> highestOccurance = new ArrayList<Node>();
		while (head.previous != null) {
			if (highestOccurance.size() == 0) {
				highestOccurance.add(new Node(head.getData()));
			}

			Node temp = head.previous;
			if (highestOccurance.size() > 1) {
				for (Node node : highestOccurance) {
					if (head.count > node.count) {
						node = head;
						head = temp;
					}
					if (head.count == node.count) {
						highestOccurance.add(head);
						head = temp;
					}
					head= head.previous;
				}
			}
		}
		return highestOccurance;
	}

	public void searchIrritating() {
		while (head.next != null) {
			if (head.getData().equalsIgnoreCase("Irritating")) {
				System.out.println(head.previous);
			}
		}
	}

}
