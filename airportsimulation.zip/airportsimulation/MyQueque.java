package airportsimulation;

interface ArQueque<T> {
	int peek();

	boolean isEmpty();

	int size();

	void offer(int i);

	int poll();
}
