
package airportsimulation;

public class AirPort {

	private int landingPlanesWithFuel;
	private int planesWithOutFuel;
	private int takeOffPlanes;

	AirPort(int a) {
		landingPlanesWithFuel = a;

	}

	public AirPort() {
		// TODO Auto-generated constructor stub
	}

	public int getLandingPlanesWithFuel() {
		return landingPlanesWithFuel;
	}

	public void setLandingPlanesWithFuel(int landingPlanesWithFuel) {
		this.landingPlanesWithFuel = landingPlanesWithFuel;
	}

	public int getPlanesWithOutFuel() {
		return planesWithOutFuel;
	}

	public void setPlanesWithOutFuel(int planesWithOutFuel) {
		this.planesWithOutFuel = planesWithOutFuel;
	}

	public int getTakeOffPlanes() {
		return takeOffPlanes;
	}

	public void setTakeOffPlanes(int takeOffPlanes) {
		this.takeOffPlanes = takeOffPlanes;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AirPort other = (AirPort) obj;
		if (landingPlanesWithFuel != other.landingPlanesWithFuel)
			return false;
		if (planesWithOutFuel != other.planesWithOutFuel)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AirPort [landingPlanesWithFuel=" + landingPlanesWithFuel + ", planesWithOutFuel=" + planesWithOutFuel
				+ ", takeOffPlanes=" + takeOffPlanes + "]";
	}

}
