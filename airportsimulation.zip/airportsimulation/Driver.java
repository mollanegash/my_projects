package airportsimulation;

import java.util.Random;

public class Driver {
	private static final double TIMME_IN_MINITES = (8 * 60);
	private static final int NUM_Landing_PLANES = 5;
	private static final int NUM_TakeOff_PLANES = 5;

	public static void main(String[] args) {
		Driver dr = new Driver();
		dr.simulate();

	}

	public void simulate() {

		ArrayQueueImpl arQ = new ArrayQueueImpl();
		/** The number of planes that took off in the simulated time **/
		// int numOfPlanesTakeOff = 0;
		// int[] take = new int[NUM_TakeOff_PLANES];
		// for (int i = 0; i < take.length; i++) {
		// AirPort takeOff = new AirPort(i);
		// take[i] = takeOff.getTakeOffPlanes();
		//
		// numOfPlanesTakeOff++;
		// arQ.poll();
		// System.out.println(arQ);
		// }

		// /**the number of planes that landed in the simulated time**/
		// int numberOfPlanes=0;
		// int[] land = new int[NUM_Landing_PLANES];
		// for (int i = 0; i < land.length; i++) {
		// AirPort landP = new AirPort(i);
		// land[i] = landP.getLandingPlanesWithFuel();
		// numberOfPlanes++;
		// arQ.offer(numberOfPlanes);
		// System.out.println(arQ);
		//
		// }
		/**
		 * the number of planes that crashed because they ran out of fuel before they
		 * could land
		 **/

		int[] lan = new int[NUM_Landing_PLANES];
		int numCrashedPlanes = 0;

		for (int i = 0; i < lan.length; i++) {
			AirPort p = new AirPort(i);
			lan[i] = NUM_Landing_PLANES - p.getLandingPlanesWithFuel();
			numCrashedPlanes += lan[i];
			// p.setPlanesWithOutFuel(numCrashedPlanes);
			// arQ.enqueue(numCrashedPlanes);
			// AirPort plan = new AirPort();
			// plan.getPlanesWithOutFuel();
			// int numcrashedPlanes = 0;
			// if (numCrashedPlanes.equals(lan) == true) {

		}
		System.out.println(arQ.poll());
		System.out.println("number of landing planes:" + arQ.size());
		System.out.println(numCrashedPlanes);

		int avArrrivalTime = 0;
		int endTime = 0;

		Random gen = new Random();
		// ArrayQueueImpl<T> q = new ArrayQueueImpl<>();
		AirPort[] takeAvT = new AirPort[NUM_TakeOff_PLANES];
		Plan pl = new Plan();
		// pl.setTimeToTakeOff(timeToTakeOff);

		for (int i = 0; i < takeAvT.length; i++) {
			takeAvT[i] = new AirPort();
		}

		int aveArrivaleTime = 9;// time in minute.
		int aveLandingTime = 9;// average time that a plane spent in the landing queue. **/
		int aveTakeOffTime = 9;//time in minute.the average time a plane spent in the take off queue;
								 

		/**
		 * the average time that a plane spent in the landing queue. average time: total
		 * time divided by number of planes gives average time to stay either the
		 * landing or take of queue. total time: sum of time all planes record.
		 */
		int aveTimePlanesArrivalRate = 3;
		//int aveTimePlanesArrivalRateTakeOff = 3;
		for (int minute = 0; minute < TIMME_IN_MINITES; minute++) {
			if (gen.nextInt(aveTimePlanesArrivalRate) == 0) {
				Plan p = new Plan();
				p.setArrivalTimeLand(minute);
				/** Average landing time is between 1 and 2 times the average -1 **/
				int tl = gen.nextInt((aveLandingTime * 2) - 1 + 1);
				p.setTimeToLand(tl);
				arQ.offer(p.getTimeToLand());

				/** Queue size:the number of planes that landed in the simulated time **/
				int size = 0;
				size = arQ.size();
				// System.out.println(size);

			}

			int aveTimePlanesArrivalRateTakeOff=6;
			/** the average time a plane spent in the take off queue **/
			 if(gen.nextInt(aveTimePlanesArrivalRateTakeOff)==0) {
			 Plan p = new Plan();
			 p.setArrivalTimeTakOff(minute);
			 int t1=gen.nextInt((aveTakeOffTime*2)-1+1);
			 p.setTimeToTakeOff(t1);
			 arQ.offer(p.getTimeToTakeOff());
			
			 /** Queue size:the number of planes that take Off in the simulated time **/
			 int size = 0;
			 size = arQ.size();
			 //System.out.println(size);
			
			 }

		}
		System.out.println("the average time that a plane spent in the landing queue:" + " " + arQ);
		System.out.println(arQ.size());
	}
}
