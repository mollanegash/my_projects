package airportsimulation;

public class Plan {
	private int timeToLand;
	private int arrivalTimeLand;
	private int endTimeToLand;
	private int aveTimeToLandQu;
	private int timeToTakeOff;
	private int aveTimeToLandTakeOff;
	private int arrivalTimeTakOff;
	private int endTimeToTakeOff;
	private int maxTStayInLanQu;
	private int totalTOFSimul;

	public int getArrivalTimeLand() {
		return arrivalTimeLand;
	}

	public void setArrivalTimeLand(int arrivalTimeLand) {
		this.arrivalTimeLand = arrivalTimeLand;
	}

	public int getEndTimeToLand() {
		return endTimeToLand;
	}

	public void setEndTimeToLand(int endTimeToLand) {
		this.endTimeToLand = endTimeToLand;
	}

	public int getAveTimeToLandTakeOff() {
		return aveTimeToLandTakeOff;
	}

	public void setAveTimeToLandTakeOff(int aveTimeToLandTakeOff) {
		this.aveTimeToLandTakeOff = aveTimeToLandTakeOff;
	}

	public int getArrivalTimeTakOff() {
		return arrivalTimeTakOff;
	}

	public void setArrivalTimeTakOff(int arrivalTimeTakOff) {
		this.arrivalTimeTakOff = arrivalTimeTakOff;
	}

	public int getEndTimeToTakeOff() {
		return endTimeToTakeOff;
	}

	public void setEndTimeToTakeOff(int endTimeToTakeOff) {
		this.endTimeToTakeOff = endTimeToTakeOff;
	}

	public int getTimeToLand() {
		return timeToLand;
	}

	/**
	 * The amount of time needed for one plane to land;
	 * 
	 * @param t
	 */
	public void setTimeToLand(int t) {
		timeToLand = t;
		t = endTimeToLand - arrivalTimeLand;
	}

	public int getTimeToTakeOff() {
		return timeToTakeOff;
	}

	/**
	 * the amount of time needed for one plane to takeoff;
	 * 
	 * @param timeToTakeOff
	 */
	public void setTimeToTakeOff(int timeToTakeOff) {
		timeToTakeOff = endTimeToTakeOff - arrivalTimeTakOff;
		this.timeToTakeOff = timeToTakeOff;
	}

	public int getAveTimeToLandQu() {
		return aveTimeToLandQu;
	}

	public void setAveTimeToLandQu(int aveTimeToLandQu) {
		this.aveTimeToLandQu = aveTimeToLandQu;
	}

	public int getMaxTStayInLanQu() {
		return maxTStayInLanQu;
	}

	public void setMaxTStayInLanQu(int maxTStayInLanQu) {
		this.maxTStayInLanQu = maxTStayInLanQu;
	}

	public int getTotalTOFSimul() {
		return totalTOFSimul;
	}

	public void setTotalTOFSimul(int totalTOFSimul) {
		this.totalTOFSimul = totalTOFSimul;
	}

}
