
package airportsimulation;

import java.util.Arrays;


public class ArrayQueueImpl implements ArQueque {
	private int[] arr = new int[10];
	private int front = -1;
	private int rear = 0;
	private int size = 0;

	public int peek() {
		if (isEmpty()) {
			System.out.println("Queue is Empty");
			return -1;
		}
		return arr[front];
	}

	public void offer(int obj) {
		if(size==arr.length) {
			resize();
		}
		
		
		if (isEmpty()) {
			arr[++front] =obj;
		
		} else {
			arr[++rear] =  obj;
			
		}
		
	}

	public int poll() {
		if (isEmpty()) {
			System.out.println("Queue is Empty");
			return -1;
		}
		int removed = arr[front];
		arr = Arrays.copyOfRange(arr, front + 1, arr.length);
		return removed;
	}

	/**
	 * avoid these errors, the queue class provides a boolean method to test for an
	 * empty queue and a second method to return the current number of items in the
	 * queue. (Java�s queue also provides two alternative methods, offer and poll,
	 * that a queue can use instead of add and remove.
	 */

	public boolean isEmpty() {
		return front == -1;
	}

	public int size() {
		return rear - front;
	}

	private void resize() {
		if (rear == arr.length) {
			int size = arr.length;
			arr = Arrays.copyOf(arr, size * 2);
		}
	}

	@Override
	public String toString() {
		return Arrays.toString(arr);
	}

	

	



	

	




}
