var employeeDB = require('../employeeDB.js');
var Employee = employeeDB.getModel();

module.exports = 
	function displayEmployees(req , res , next){
        
};
