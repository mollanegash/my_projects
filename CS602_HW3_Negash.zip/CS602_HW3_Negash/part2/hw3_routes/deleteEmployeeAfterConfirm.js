var employeeDB = require('../employeeDB.js');
var Employee = employeeDB.getModel();

module.exports = 
	function deleteEmployeeAfterConfirm(req , res , next){
    
  };

  