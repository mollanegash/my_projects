var employeeDB = require('../employeeDB.js');
var Employee = employeeDB.getModel();

module.exports = 
	function deleteEmployee(req , res , next){
    
  };

  