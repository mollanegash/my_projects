var employeeDB = require('../employeeDB.js');
var Employee = employeeDB.getModel();

module.exports = 
	function editEmployee(req , res , next){
    
};

