var employeeDB = require('../employeeDB.js');
var Employee = employeeDB.getModel();

module.exports = 
  function saveEmployee(req , res , next){
    
  };
