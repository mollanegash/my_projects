var mongoose = require('mongoose');

const credentials = require("./credentials.js");

const dbUrl = 'mongodb://' + credentials.username +
	':' + credentials.password + '@' + credentials.host + ':' + credentials.port + '/' + credentials.database;

var connection = null;
var model = null;

var Schema = mongoose.Schema;

// Complete the schema definition

var employeeSchema = new Schema({


	firstName: String,
	lastName: String,
	employeeSchema: [
		{firstName: String, lastName: String}
	]
	
}, {
	collection: 'employees'
});

module.exports = {	
	getModel: () => {
		if (connection == null) {
			console.log("Creating connection and model...");
			connection = mongoose.createConnection(dbUrl, { useNewUrlParser: true });
			model = connection.model("EmployeeModel", 
							employeeSchema);
		};
		return model;
	}
};
























