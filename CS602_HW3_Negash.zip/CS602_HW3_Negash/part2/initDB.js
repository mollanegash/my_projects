const EmployeeDB = require('./employeeDB.js');

var Employee = EmployeeDB.getModel();

Employee.deleteMany({}, async (err) => {
	// create and save document objects
	var employee;

	employee = new Employee({
		firstName:'John',lastName:'Smith'
	}); 
	await employee.save();

	employee = new Employee({
		firstName:'Jane',lastName:'Smith'
	}); 
	await employee.save();

	employee = new Employee({
		firstName:'John',lastName:'Doe'
	}); 
	await employee.save(function(err) {
		if (err) throw err;
		console.log("Success!");
		process.exit();
	});

});
	










