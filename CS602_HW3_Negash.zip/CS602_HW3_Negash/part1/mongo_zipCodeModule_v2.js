const MongoClient = require('mongodb').MongoClient;
const credentials = require("./credentials.js");

const dbUrl = 'mongodb://' + credentials.username +
	':' + credentials.password + '@' + credentials.host + ':' + credentials.port + '/' + credentials.database;
//	console.log(dbUrl)

let client = null;

const getConnection = async () => {
	if (client == null)
		client = await MongoClient.connect(dbUrl,  { useNewUrlParser: true ,  useUnifiedTopology: true });
		return client;
}

module.exports.lookupByZipCode =  async (zip) => {	
	let client = await getConnection();
	let collection = client.db(credentials.database).collection('zipcodes');

	
	// Complete  the rest of the code
	return new Promise(function(resolve, reject) {
		collection.find({"_id": zip}).toArray( function(err, docs) {
		 if (err) {
		   // Reject the Promise with an error
		   return reject(err)
		 }
   
		 // Resolve (or fulfill) the promise with data
		 return resolve(docs)
	   })
	 })
};

module.exports.lookupByCityState = async (city, state) => {

	let client = await getConnection();
	let collection = client.db(credentials.database).collection('zipcodes');
	
	// Complete  the rest of the code

	let data = await new Promise(function (resolve, reject) {
		collection.find({city: city, state: state}).toArray( function(err, docs) {
			if (err) {
				reject(err)
			}
			return resolve(docs)
		})
	})

    return ({'city': city, 'state': state, 'data': data});

};

module.exports.getPopulationByState = 
	async (state) => {

		let client = await getConnection();
		let collection = client.db(credentials.database).collection('zipcodes');

		let data = await new Promise(function (resolve, reject) {
			collection.find({'state': state}).toArray( function(err, docs) {
				if (err) {
					reject(err)
				}
				return resolve(docs)
			})
		})
	
		return ({'state': state, 'pop':data});

	}