const express = require('express');
const app = express();

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// setup handlebars view engine
const handlebars = require('express-handlebars');

app.engine('handlebars', 
	handlebars({defaultLayout: 'main'}));

app.set('view engine', 'handlebars');

// static resources
app.use(express.static(__dirname + '/public'));

// Use the zipcode module
const cities = require('./mongo_zipCodeModule_v2');


// GET request to the homepage

app.get('/',  (req, res) => {
	res.render('homeView');
	
});

app.get('/zip', function(req, res) {
	//res.render('lookupByZipCode');
	if(req.query.id){
		let id = req.query.id;
		let result = cities.lookupByZipCode(id);
		res.render('lookupByZipView', result);
		
	}else{
		res.render('lookupByZipForm')
	}


	


	

});

app.post('/zip', (req, res) => {

	let id = req.body.id;
	let result = cities.lookupByZipCode(id);
	res.render('lookupByZipView', result);	

	
	

});


app.get('/zip/:id', (req, res) => {

	let id =req.param.id;
	let result = cities.lookupByZipCode(id);
	res.format({
		'application/json': function(){
			res.json(result);

		},
		'application/xml': function(){
			let resultxml = 
			'<?xml version="1.0"?>\n' +
					'zipCode id=" ' + result._id + '">\n' + 
					'<city> ' + result.city + ' </city>\n' + 
					'<state>' + resulty.state + '</state>\n' + 
					'<pop>' + result.pop + '</pop>\n' +
					'</zipCode>\n';
					res.type('application/xml');
			res.send(resultxml);
			
		},
		'text/html': function(){
			res.render('lookupByCityState', result);
		}
	})


});



app.get('/city', function(req, res) {
	
		if((req.query.city) && (req.query.state)){
					let city = req.query.city;
					let state = req.query.state;
					let result = cities.lookupByCityState(city, state);
					res.render('lookupByCityStateView');
				}else{
					res.render('lookupByCityStateForm');
				}
});

app.post('/city', function(req, res){
	let city = req.body.city;
	let state =req.body.state;
	let result = cities.lookupByCityState(city, state);
	res.render('lookupByCityStateView', result);

	
	
	

});

app.get('/city/:city/state/:state', function(req, res) {
	let city = req.param.city;
let state = req.param.state;
let result = cities.lookupByCityState;

res.format({
	'application/json': function(){
		res.json(result);
	},

	'application/xml': function(){
		let resultXml=

		'<?xml version = "1.0"?>\n' + 
		'<city- state city="' + result.city + ' "state=" ' + result.state + '>'
		result.data.map(elem => {
			let str = ' <entry zip="' + elem.zip + '" pop="' + elem.pop + '>' 
			return str;

		}).join("\n")
		+ '\n</city-state>\n';

		res.type('application/xml');
		res.send(resultXml);
	
	
	},
	
	'text/html': function(){
		res.render('lookupByCityStateView', result);
	}
});




		


});



app.get('/pop', (req, res) => {
	
	if(req.query.state){
		let state = req.query.state;
		let result = cities.getPopulationByState(state);
		res.render('populationView', result);

	}else{
		res.render('populationForm');
	}
});

app.get('/pop/:state', (req, res) => {
	res.format({

		'text/html': () => {
			let pophtml = req.populationView(state);
			res.type('text/html');
			res.send(pophtml);
		},
				
	});

});


app.use((req, res) => {
	res.status(404);
	res.render('404');
});

app.listen(3000, () => {
  console.log('http://localhost:3000');
});




