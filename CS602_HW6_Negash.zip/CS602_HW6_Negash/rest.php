<?php
require_once('database.php');
if(!empty($_GET['format']) && !empty($_GET['action'])){
try{
	//get format info
	$format=trim($_GET['format']); 
	//get action info
	$action=trim($_GET['action']);
	//get course id if any
	$course=empty($_GET['course'])?"":$_GET['course'];
	
	if($action=="courses"){
		$q="select * from sk_courses ";
		if(!empty($course)){
			$q.=" where courseID='$course'";
		}else{
			$q.=" order by courseID asc" ;
		}
	}else{
		$q="select * from sk_students ";
		if(!empty($course)){
			$q.=" where courseID='$course'";
		}
	}
	$data=$db->query($q)->fetchAll(PDO::FETCH_ASSOC);
	
	//echo "<pre>";var_dump($data);die;
	if($format=="xml"){
		$xml_doc=new DOMDocument();
		$root=$xml_doc->createElement($action);
		foreach($data as $d){
			if($action=="courses"){
				$course=$xml_doc->createElement('course');
				$course->appendChild($xml_doc->createElement('courseID',$d['courseID']));
				$course->appendChild($xml_doc->createElement('courseName',$d['courseName']));
				$root->appendChild($course);
			}
			else{
				$course=$xml_doc->createElement('student');
				$course->appendChild($xml_doc->createElement('studentID',$d['studentID']));
				$course->appendChild($xml_doc->createElement('courseID',$d['courseID']));
				$course->appendChild($xml_doc->createElement('firstName',$d['firstName']));
				$course->appendChild($xml_doc->createElement('lastName',$d['lastName']));
				$course->appendChild($xml_doc->createElement('email',$d['email']));
				$root->appendChild($course);
			}
			
		}
		$xml_doc->appendChild($root);
		header('Content-Type: application/xml;charset=UTF-8;');
		echo $xml_doc->saveXML();
	}
	else{	
		header('Content-Type: application/json; charset=UTF-8;');
		echo json_encode($data,JSON_PRETTY_PRINT);
	}
} 
catch (PDOException $e) {
	 echo 'Error Message: ' .$e->getMessage();
}
}else{
	echo "Invalid Request!";
}
?>