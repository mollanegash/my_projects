<?php
require_once('database.php');

//fetching list of courses and student inrolled in first course_list

try{

	$q1="select * from sk_courses order by courseID asc";
	$courses=$db->query($q1)->fetchAll();
	if(!empty($_GET['course_id'])){
		$selected_course=trim($_GET['course_id']);
	}else{
		$selected_course=$courses[0]['courseID'];
	}
	$q2="select * from sk_students where courseID='$selected_course'";
	$students=$db->query($q2);
	$course=$db->query("select * from sk_courses where courseID='$selected_course'")->fetch();
	
	//var_dump($students);die;
} 
catch (PDOException $e) {
	 echo 'Error Message: ' .$e->getMessage();
}



?>

<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>My Course Manager</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>

<!-- the body section -->
<body>
<header><h1>Course Manager</h1></header>
<main>
    <center><h1>Student List</h1></center>

    <aside>
        <!-- display a list of categories -->
        <h2>Courses</h2>
        <nav>
        <ul>
            <?php 

				foreach($courses as $c){
					echo "<li><a href='?course_id=".$c['courseID']."'>".$c['courseID']."</a></li>";
				}
			?>
        </ul>
        </nav>          
    </aside>

    <section>
	 <h2><?php echo $course['courseID'].'-'.$course['courseName'];?></h2>
        <!-- display a table of Students -->
        
        <table>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>&nbsp;</th>
            </tr>
			<?php 
			while($st=$students->fetch()){	
					echo "<tr>";
					echo "<td>".$st['firstName']."</td>";
					echo "<td>".$st['lastName']."</td>";
					echo "<td>".$st['email']."</td>";
					echo "<td><form method='post' action='delete_student.php'><input type='hidden' name='student_id' value='".$st['studentID']."'><input type='submit' value='delete'></form></td>";
					echo "</tr>";
			}
			?>
            
        </table>

        <p><a href="add_student_form.php">Add Student</a></p>

        <p><a href="course_list.php">List Courses</a></p>    

    </section>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Suresh Kalathur</p>
</footer>
</body>
</html>
