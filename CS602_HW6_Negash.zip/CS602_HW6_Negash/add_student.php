<?php
    
	require_once('database.php');
if(!empty($_POST) ){
// Get the student form data
	$course_id=trim($_POST['course_id']);
	$first_name=trim($_POST['first_name']);
	$last_name=trim($_POST['last_name']);
	$email=trim($_POST['email']);

// Add the student to the database  
	try{
		$q = "insert into sk_students(courseID,firstName,lastName,email) VALUES (?,?,?,?)";
		$stm=$db->prepare($q)->execute([$course_id,$first_name,$last_name,$email]);
	}
	catch (PDOException $e) {
	 echo 'Error Message: ' .$e->getMessage();
	}
}

    // Display the Student List page
    include('index.php');

?>