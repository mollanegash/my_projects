<?php
    require_once('database.php');

// Get the course form data
if(!empty($_POST['course_id']) && !empty($_POST['course_name'])){
	$course_id=trim($_POST['course_id']);
	$course_name=trim($_POST['course_name']);
	 // Add the course to the database  
	try{
		$q = "insert into sk_courses(courseID,courseName) VALUES (?,?)";
		$stm=$db->prepare($q)->execute([$course_id,$course_name]);
	}
	catch (PDOException $e) {
	 echo 'Error Message: ' .$e->getMessage();
	}
}

   
   
   
    // Display the Course List page
    include('course_list.php');
   // echo 0;
    

?>