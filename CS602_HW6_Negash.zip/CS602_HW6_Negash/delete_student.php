<?php
require_once('database.php');

// Delete the student from the database
if(!empty($_POST['student_id'])){
	try{
		$student_id=trim($_POST['student_id']);
		$q = "delete from sk_students where studentID=?";
		$stm=$db->prepare($q)->execute([$student_id]);
	}
	catch (PDOException $e) {
	 echo 'Error Message: ' .$e->getMessage();
	}
}

// Display the Home page
include('index.php');