<?php
        // server
        $serverName = "localhost";
        $userName = "root";
        $password ="";
        $dbname = "cs602db";



        // connecto to the database: mysql: OOP
        $conn = new  mysqli($serverName, $userName, $password, $dbname);
        
        //check error
        if($conn->connect_error){
            die("connection g = failed: ".  $conn->connect_error);
        }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title> insert with a form</title>
</head>
<body>
   


    <form method="POST" action="course_list.php">
    id:<input type="text" name="id"><br>
    First Name:<input type="text" name="fname"><br>
    Last Name:<input type="text" name="lname"><br>
    email:<input type="text" name="email"><br>
            <input type="submit" name="submit" value="register">

    </form>

    




<?php
//check method
//check super globale variable
if($_SERVER["REQUEST_METHOD"] == "POST"){
    IF(empty($_POST['id'])||(empty($_POST['fname'])) || (empty($_POST['lname']))||(empty($_POST['email']))){
        echo "name is required";

    } 
    else 
    {

        $stmt = $conn->prepare("INSERT INTO WEBVISTORS (USERID,firstName, lastName, email) values (?, ?,?,?) ");
        $stmt->bind_param("ssss", $id, $fname,$lname,$email);//ss  data type:both are string

        $id =$_POST['id'];
        $fname =$_POST['fname'];
        $lname =$_POST['lname'];
        $email =$_POST['email'];
        $stmt->execute();    

    

        echo "<br>";
        //create database
        //$sql ="CREATE DATABASE modeldatabase";
        //excute oop
     
}
}
       
            ?>



           </body>
<html>