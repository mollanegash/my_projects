use database_dump.sql to populate the database and modify database.php if required 


[credentials]

username: admin@test.com
password: admin

username:student1@test.com
password: student

username:student2@test.com
password: student
